const express = require("express");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const session = require("express-session");
const passport = require("passport");
const cors = require('cors');
const LocalStrategy = require('passport-local').Strategy;
const mongoose = require("mongoose");
const multer = require('multer')
const { ObjectId } = require('mongodb');
const fs = require('fs');
const path = require('path');
const { MongoClient } = require('mongodb');

app = express();
const port = 4444;
app.use(express.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(cors({
    origin: 'http://localhost:3000', // Allow requests from localhost:3000
    credentials: true // Allow credentials (cookies, authorization headers, etc.)
  }));

  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'images/');
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname);
        const filenameWithoutExt = path.basename(file.originalname, ext);
        
        let newFilename = file.originalname;

        // Check if the file with the same name exists
        const filePath = path.join(__dirname, 'images/', file.originalname);
        if (fs.existsSync(filePath)) {
            // Append a unique identifier (timestamp) to the filename
            newFilename = `${filenameWithoutExt}_${Date.now()}${ext}`;
        }

        cb(null, newFilename);
    },
});

const dbase=null;
const upload = multer({ storage: storage });
app.use('/images', express.static(path.join(__dirname, 'images')));
mongoose.connect("mongodb+srv://sanjaykumar9949088606:oHazfu5DcCRcVh5b@cluster0.te7hirj.mongodb.net/SE", {useNewUrlParser: true});
const client = new MongoClient("mongodb+srv://sanjaykumar9949088606:oHazfu5DcCRcVh5b@cluster0.te7hirj.mongodb.net/")
client.connect()
// mongo.connect(
//     "mongodb+srv://sanjaykumar9949088606:oHazfu5DcCRcVh5b@cluster0.te7hirj.mongodb.net/",(err,database)=>{
//         dbase = database.db("SE").collection("datas")
//     });
    
const userSchema = {
    fname:String,
    lname:String,
    username:String,
    password:String,
    company:String
};
const inventorySchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    company: {
        type: String,
        required: true
    },
    url: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    quantity: {
        type: Number,
        required: true
    }
});

const User = mongoose.model("User",userSchema);
const InventoryData = mongoose.model('Data', inventorySchema);



app.use(session({
    secret:"sanjay",
    resave:false,
    saveUninitialized:true,
    cookie:{
      maxAge:1000*60*60*24
    }
  }));
app.use(passport.initialize());
app.use(passport.session());


app.get('/logout', (req, res) => {
    // Clear session cookie
    req.session.destroy(err => {
        if (err) {
            console.error('Error destroying session:', err);
            return res.status(500).json({ message: 'Failed to logout' });
        }
        // If session is successfully destroyed, send success response
        res.clearCookie('connect.sid');
        return res.json({ message: 'success' });
    });
});


const isAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
        // If user is authenticated, proceed to the next middleware
        return next();
    } else {
        // If user is not authenticated, return an error response
        return res.status(401).json({ message: false });
    }
};

// Protected route that requires authentication
app.get('/login-home', isAuthenticated, (req, res) => {
    // If user is authenticated, they can access this route
    res.json({ message: true });
});


app.post("/register",async (req,res)=>{

    const jsonData = req.body;
    const email = jsonData.username;
    const password = jsonData.password;
    const fname = jsonData.fname;
    const lname = jsonData.lname;
    const company = jsonData.company;

    try {
        
        const emailCheck = await User.findOne({username:email})
        if(emailCheck){
            return res.status(400).json({ error: "Email already exists. Try logging in." });
        }else{
            bcrypt.hash(password,10,async (err,hash)=>{

                if(err){
                    return res.status(500).json({ error: "Error hashing password" });
                }
                else{
                      const new_user = new User({
                        username:email,
                        password:hash,
                        fname:fname,
                        lname:lname,
                        company:company
                      });
                      new_user.save();
                      return res.status(201).json({ message: "User registered successfully", new_user });
                }

            })
        }
    } catch (error) {
        return res.status(500).json({ error: "Error inserting user into database" });
                    
    }
    
    
    // console.log(jsonData.fname);

});

passport.use(new LocalStrategy(async (username, password, cb) => {
    // console.log(email,password);
    try {

        await User.findOne({username:username})
        .then(user=>{
            if(!user){
                return cb(null, false, { message: 'Incorrect email.' });
            }
            if (!bcrypt.compareSync(password, user.password)) {
                return cb(null, false, { message: 'Incorrect password.' });
            }
            return cb(null, user);
        })
    } catch (err) {
        return cb(err);
    }
}));

passport.serializeUser((user, cb) => {
    cb(null, user);
});

passport.deserializeUser(async (user, cb) => {
   cb(null,user)
   
});

app.post('/login', (req, res, next) => {
    // console.log(req.body.email);
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return next(err);
        }
        
        if (!user) {
            return res.status(401).json({ message: "Incorrect credentials" });
        }
        req.logIn(user, (err) => {
            if (err) {
                return next(err);
            }
            return res.json({ message: 'Login successful', user: user });
        });
    })(req, res, next);
});

app.post("/changepassword",async (req,res,next)=>{
    const jsonData = req.body;
    const email = jsonData.username;
    const password = jsonData.password;
    const fname = jsonData.fname;
    const lname = jsonData.lname;

    try {
        
        const emailCheck = await User.findOne({username:email})
       
           
            if(emailCheck){
            bcrypt.hash(password,10,async (err,hash)=>{

                if(err){
                    return res.status(500).json({ error: "Error hashing password" });
                }
                else{
                      const new_user = User.findOneAndUpdate({username:email},{password:hash})
                      .then(data=>{
                            return res.status(201).json({ message: "Password Changed Successfully", new_user });
                      })
                      .catch(err=>{
                        return res.status(500).json({ error: "Error Updating Password" });
                      })
                }

            })
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({ error: "Error inserting user into database" });
                    
    }
})

app.post('/image', upload.single('file'), function (req, res) {
    const imageUrl = `http://localhost:${port}/images/${req.file.filename}`;
    res.json({ imageUrl });
});

app.get('/inventory_data',(req,res)=>{

    // console.log("user......",req.user.company);
    // console.log("dsadas",res.json(req.user));

    try{
        InventoryData.find({company:req.user.company}).then(data=>{return res.json({data:data})})
    }
    catch (error){
        return res.json({error:error})

    }
});

app.post("/editItem",(req,res)=>{
    // console.log(req.session);
    const jsonData = req.body;
    // console.log(jsonData);
    try {
        InventoryData.findByIdAndUpdate(jsonData._id,{name:jsonData.name,category:jsonData.category,price:jsonData.price,quantity:jsonData.quantity})
        .then(updatedDoc => {
            // If document is successfully updated
            console.log("Document updated:", updatedDoc);
            res.status(200).send("Document updated successfully");
        })
        .catch(error => {
            // If an error occurs during the update process
            console.error("Error updating document:", error);
            res.status(500).send("Error updating document");
        });
    } catch (error) {
        return res.status(500).json({ error: "Error inserting user into database" });
                    
    }

})

app.delete("/deleteItem/:id",(req,res)=>{
    try {
        InventoryData.findByIdAndDelete(req.params.id)
        .then(deleted=>{
            console.log(deleted);
        })
        .catch(error => {
            // If an error occurs during the update process
            console.error("Error updating document:", error);
            res.status(500).send("Error updating document");
        });
    } catch (error) {
        return res.status(500).json({ error: "Error inserting user into database" });
                       
    }
})

app.get("/search/:name",async (req,res)=>{

    const data = req.params.name;
    const agg = [
        {
          '$search': {
            'text': {
              'query': data, 
              'path': [
                'name', 'description'
              ]
            }
          }
        }, {
          '$sort': {
            'price': 1
          }
        },
        { '$match' : { 'company' : req.user.company } } 
      ];
      const db = client.db("SE");
      const collection = db.collection('datas');
      const cursor = collection.aggregate(agg);
      const result =  await cursor.toArray();
    return res.json({data:result})
})

app.post("/addItem",(req,res)=>{

    const jsonData = req.body;
    // console.log(req.session);

    try {

        const new_item = new InventoryData({
            name:jsonData.name,
            category:jsonData.category,
            price:jsonData.price,
            quantity:jsonData.quantity,
            description:jsonData.description,
            company:req.user.company,
            url:jsonData.url
        })
        new_item.save();
        return res.status(201).json({ message: "Item stored successfully", new_item });
        
    } catch (error) {
        return res.status(500).json({ error: "Error inserting data into database" });
        
    }

})

app.get("/item/:id",(req,res)=>{

    try {
        InventoryData.findById(req.params.id)
        .then(data=>{return res.json({data:data})})
        .catch(err=>{return res.status(500).json({ error: "Error inserting user into database" })})
    } catch (error) {
        return res.status(500).json({ error: "Error Connecting to database" });
    }

})




app.get('/api/portfolio',function(req,res){
    
    return res.json(req.user);
});


app.listen(port,()=>{
    console.log(`server running on port ${port}`);
})