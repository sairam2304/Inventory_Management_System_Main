// const express = require('express')
// const app = express()
// const port = 5000
// const cors = require('cors')
// const multer = require('multer')

// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     cb(null, 'images/')
//   },
//   filename: (req, file, cb) => {
//     cb(null, file.originalname)
//   },
// })

// const upload = multer({ storage: storage })

// app.use(cors())

// app.post('/image', upload.single('file'), function (req, res) {
//   res.json({})
// })

// app.listen(port, () => {
//   console.log(`listening at http://localhost:${port}`)
// })


// const express = require('express');
// const app = express();
// const port = 5000;
// const cors = require('cors');
// const multer = require('multer');

// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     cb(null, 'images/');
//   },
//   filename: (req, file, cb) => {
//     cb(null, file.originalname);
//   },
// });

// const upload = multer({ storage: storage });

// app.use(cors());

// app.post('/image', upload.single('file'), function (req, res) {
//   const imageUrl = `http://localhost:5000/${req.file.path}`;
//   res.json({ imageUrl });
// });

// app.listen(port, () => {
//   console.log(`listening at http://localhost:${port}`);
// });

const express = require('express');
const app = express();
const port = 5000;
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'images/');
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const filenameWithoutExt = path.basename(file.originalname, ext);
    
    let newFilename = file.originalname;

    // Check if the file with the same name exists
    const filePath = path.join(__dirname, 'images/', file.originalname);
    if (fs.existsSync(filePath)) {
      // Append a unique identifier (timestamp) to the filename
      newFilename = `${filenameWithoutExt}_${Date.now()}${ext}`;
    }

    cb(null, newFilename);
  },
});

const upload = multer({ storage: storage });

app.use(cors());
app.use('/images', express.static(path.join(__dirname, 'images')));

app.post('/image', upload.single('file'), function (req, res) {
  const imageUrl = `http://localhost:${port}/images/${req.file.filename}`;
  res.json({ imageUrl });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
