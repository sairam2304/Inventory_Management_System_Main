// const express = require("express");
// const bodyParser = require("body-parser");
// const pg = require("pg");
// const bcrypt = require("bcrypt");
// const session = require("express-session");
// const passport = require("passport");
// const cors = require('cors');
// const LocalStrategy = require('passport-local').Strategy;
// const mongoose = require("mongoose");
// const fileUpload = require("express-fileupload");
// import { MongoClient } from 'mongodb';

// app = express();
// const port = 5555;
// app.use(express.json());
// app.use(bodyParser.urlencoded({extended:true}));
// app.use(bodyParser.json());
// app.use(cors());
// app.post('/upload', (req, res) => {
//     if (!req.files || Object.keys(req.files).length === 0) {
//       return res.status(400).send('No files were uploaded.');
//     }
//     console.log(req);
//     const image = req.files.image;
    
//     const uploadPath = path.join(__dirname, 'public/images/', image.name);
  
//     image.mv(uploadPath, (err) => {
//       if (err) {
//         console.error(err); // Log the error
//         return res.status(500).send(err);
//       }
  
//       res.send('File uploaded!');
//     });
//   });
  
//   // Start the server
//   const PORT = process.env.PORT || 5000;
//   app.listen(PORT, () => {
//     console.log(`Server is running on port ${PORT}`);
//   });

// // const inventorySchema = new mongoose.Schema({
// //     name: {
// //         type: String,
// //         required: true
// //     },
// //     category: {
// //         type: String,
// //         required: true
// //     },
// //     price: {
// //         type: Number,
// //         required: true
// //     },
// //     quantity: {
// //         type: Number,
// //         required: true
// //     }
// // });

// // Create a model based on the schema
// // const InventoryData = mongoose.model('Data', inventorySchema);


// // const User = mongoose.model("User",userSchema);

// // // const Items = mongoose.model("inventory_data", itemSchema);


// // const item = new User({
// //     username:"sanjay@gmail.com",
// //     password:"sanjay"
// // })

// // item.save()

// // // InventoryData.find({})
// // //     .then(data => {
// // //         console.log(data);
// // //     })
// // //     .catch(error => {
// // //         console.error(error);
// // //     });

// // // console.log("lign ",user);
// // app.listen(port,()=>{
// //     console.log(`server running on port ${port}`);
// // })

// import { MongoClient } from 'mongodb';

const mongo = require("mongodb");
/*
 * Requires the MongoDB Node.js Driver
 * https://mongodb.github.io/node-mongodb-native
 */

const agg = [
  {
    '$search': {
      'text': {
        'query': 'play', 
        'path': [
          'name', 'description'
        ]
      }
    }
  }, {
    '$sort': {
      'price': 1
    }
  }
];

const f = async ()=>{

  const client =  await mongo.MongoClient.connect(
    "mongodb+srv://sanjaykumar9949088606:oHazfu5DcCRcVh5b@cluster0.te7hirj.mongodb.net"
  );
  console.log(client);
  const coll = client.db('SE').collection('datas');
  const cursor = coll.aggregate(agg);
  const result =  await cursor.toArray();
  await client.close();
  
  console.log(result);

}

f()

