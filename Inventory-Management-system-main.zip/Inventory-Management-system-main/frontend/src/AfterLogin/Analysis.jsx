import React, { useState } from 'react'
import Header from '../Header/header';
import { Chart } from "react-google-charts";
import "./Analysis.css";
function Analysis() {

    const [data,setData] = useState([]);

    fetch("http://localhost:4444/inventory_data", {
        method: "get",
        credentials:"include",
        headers: {
            "Content-Type": "application/json",
        },
    })
        .then(response => response.json())
        .then(data => {
            setData(data.data);
        })
        .catch(error => console.error(error));

        const groupedData = data.reduce((groups, item) => {
        const { category, quantity } = item;
        if (!groups[category]) {
            groups[category] = { category, totalQuantity: 0 };
        }
        groups[category].totalQuantity += quantity;
        return groups;
    }, {});

    const chartDataGroup = [
        ['Category', 'Total Quantity'], // Column headers
        ...Object.values(groupedData).map(({ category, totalQuantity }) => [category, totalQuantity]) // Transform grouped data into chart data
    ];
    const chartData = [
        ['Name', 'Quantity'], // Column headers
        ...data.map(item => [item.name, item.quantity]) // Transform each item into [name, quantity]
    ];
    const pieOptions = {
        title: "Category Count",
        is3D: true,
    };
    const bubbleChartData = data.map(item => [item.name, item.price, item.quantity,item.price*item.quantity]);
    const bubbleChartData1 = [["name","price","quantity","value"]].concat(bubbleChartData)

    const bubbleOptions = {
        title:
          "Correlation between price, quantity " +
          "and overall value of current products",
        hAxis: { title: "Price" },
        vAxis: { title: "Quantity" },
        bubble: { textStyle: { fontSize: 11 } },
      };
    // console.log(data);
const data1 = [
    ["name", "price", "quantity", "value"],
    ['Iphone 15 pro', 1089, 50, 54450],
    ['Play Station 4', 400, 12, 4800]
    // ["", 78, 184, 50],
    // ["", 72, 278, 230],
    // ["", 81, 200, 210],
    // ["", 72, 170, 100],
    // ["", 68, 477, 80],
  ];
  return (
    <div className='home-container'>
        <Header to="user"/>
         
                        <Chart
                            className='chart'
                            chartType="PieChart"
                            data={chartDataGroup}
                            options={pieOptions}
                            width="100%"
                            height="400px"
                            legendToggle
                        />
                        <Chart
                            className='chart'
                            chartType="Bar"
                            data={chartData}
                            width="100%"
                            height="400px"
                            legendToggle
                        />
                        <Chart
                            chartType="BubbleChart"
                            width="100%"
                            height="400px"
                            data={bubbleChartData1}
                            options={bubbleOptions}
                        />
        </div>
  )
}

export default Analysis