import React, { useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useState } from 'react';
import Header from '../Header/header';
import { TextField } from '@mui/material';
import { Button } from 'react-bootstrap';
import Select from 'react-select'
import { useNavigate } from 'react-router-dom';
import Input from '@mui/material';
import { TextareaAutosize } from '@mui/base/TextareaAutosize';


import "./EditInv.css"

function EditInv() {
const [image, setImage] = useState({ preview: '', data: '' })
// const [status, setStatus] = useState('') 
const [imgUrl, setImgUrl] = useState(""); 
const [disable, setDisable] = useState(false); 
const navigate = useNavigate()
const [data, setData] = useState()

const categories = [
    { value: 'Electronics', label: 'Electronics' },
    { value: 'Clothing', label: 'Clothing' },
    { value: 'Furniture', label: 'Furniture' },
    { value: 'Books', label: 'Books' },
    { value: 'Office Supplies', label: 'Office Supplies' },
    { value: 'Home Appliances', label: 'Home Appliances' },
    { value: 'Sporting Goods', label: 'Sporting Goods' },
    { value: 'Toys', label: 'Toys' },
    { value: 'Automotive Parts', label: 'Automotive Parts' },
    { value: 'Beauty and Personal Care Products', label: 'Beauty and Personal Care Products' },
    { value: 'Health and Wellness Products', label: 'Health and Wellness Products' },
    { value: 'Food and Beverages', label: 'Food and Beverages' },
    { value: 'Home Decor', label: 'Home Decor' },
    { value: 'Kitchenware', label: 'Kitchenware' },
    { value: 'Pet Supplies', label: 'Pet Supplies' },
    { value: 'Outdoor Equipment', label: 'Outdoor Equipment' },
    { value: 'Tools and Hardware', label: 'Tools and Hardware' },
    { value: 'Baby Products', label: 'Baby Products' },
    { value: 'Jewelry and Accessories', label: 'Jewelry and Accessories' },
    { value: 'Arts and Crafts Supplies', label: 'Arts and Crafts Supplies' },
    { value: 'Musical Instruments', label: 'Musical Instruments' },
    { value: 'Stationery', label: 'Stationery' },
    { value: 'Gardening Supplies', label: 'Gardening Supplies' },
    { value: 'Party Supplies', label: 'Party Supplies' },
    { value: 'Travel Accessories', label: 'Travel Accessories' },
    { value: 'Fitness Equipment', label: 'Fitness Equipment' },
    { value: 'Computer Accessories', label: 'Computer Accessories' },
    { value: 'Mobile Accessories', label: 'Mobile Accessories' },
    { value: 'Educational Supplies', label: 'Educational Supplies' },
    { value: 'Cleaning Supplies', label: 'Cleaning Supplies' }
  ];
  
  const handleSubmitImage = async (e) => {
    e.preventDefault()
    let formData = new FormData()
    formData.append('file', image.data)
    fetch('http://localhost:4444/image', {
      method: 'POST',
      body: formData,
    })
    .then(response=>response.json())
    .then(data=>{

      setImgUrl(data.imageUrl);
      setDisable(true);


    })
    // if (response) setStatus(response.statusText)
  }
  const handleFileChange = (e) => {
    const img = {
      preview: URL.createObjectURL(e.target.files[0]),
      data: e.target.files[0],
    }
    setImage(img)
  }

  function handleSubmit() {

    if(!disable){
      alert("Submit image first");
      return
    }

    console.log(data);
    data["url"]=imgUrl;

    fetch("http://localhost:4444/addItem",{
        method:"post",
        credentials:"include",
        headers:{
          "Content-Type": "application/json",
        },
        body:JSON.stringify(data)
      }
      )
      .then(response=>response.json())
      .then(data=>{
        if(data.message){
          alert(data.message);
        }else{
          alert(data.error);
        }
      })
      .catch(error=>console.error(error))
    //    console.log(updatedData);
    navigate("/home")
  

    
    
  }


return (
<div className='home-container'>
    <Header to="user" />


        <h1>Enter Inventory Details</h1>

        <div className='form'>
          <div style={{margin:"80px"}}>

          </div>
        {image.preview && <img src={image.preview} width='100' height='100' />}
            <input type='file' name='file' onChange={handleFileChange}></input>
            <Button type='submit' onClick={handleSubmitImage} disabled={disable}>Submit</Button>
            <br></br>
        <TextField type="string" label="Item Name" variant="outlined" sx={{margin:"2% auto",width:"80%"}} required onChange={(e)=>setData({...data, name:e.target.value})} />
        <br />

        <Select className='select' options={categories} required  onChange={(e)=>setData({...data, category:e.value})}/>
        <br />

        <textarea style={{"width":"80%"}} maxLength={400} placeholder='Enter Description' required onChange={(e)=>setData({...data, description:e.target.value})}></textarea><br/>

        <TextField type="Number" label="Price" variant="outlined" sx={{margin:"2% auto",width:"80%"}} required  onChange={(e)=>setData({...data, price:e.target.value})}/><br />

        <TextField type="Number" label="Quantity" variant="outlined" sx={{margin:"2% auto",width:"80%"}} required onChange={(e)=>setData({...data, quantity:e.target.value})}/>
        <br />
        <Button type='submit'onClick={handleSubmit} >Submit</Button>
        </div>
    


</div>
)
}

export default EditInv