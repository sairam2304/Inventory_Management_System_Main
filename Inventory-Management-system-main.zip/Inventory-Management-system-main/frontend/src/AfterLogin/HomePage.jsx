import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import Header from '../Header/header';
import { DataGrid } from '@mui/x-data-grid';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {  faTrash,faEye } from '@fortawesome/free-solid-svg-icons';
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import "./HomePage.css";
import { TextField } from '@mui/material';
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';

function Home() {
    const [authorization, setAuthorization] = useState();
    const [data, setData] = useState([]);
    const [search, setSearch] = useState("")
    const [lowItem, setLowItem] = useState([])
    const [open,setOpen] = useState(false);
    const location = useLocation();
    const clseModel = ()=>setOpen(false)
    const count=0;
    useEffect(() => {

        if(search.length>2){
            fetch(`http://localhost:4444/search/${search}`,{
        method:"get",
        credentials:"include",
        headers: {
            "Content-Type": "application/json",
        },
      })
      .then(response=>response.json())
      .then(data=>setData(data.data))
      .catch(err=>console.error(err))
        } else{
            fetch("http://localhost:4444/inventory_data", {
                method: "get",
                credentials:"include",
                headers: {
                    "Content-Type": "application/json",
                },
            })
                .then(response => response.json())
                .then(data =>setData(data.data))
                .catch(error => console.error(error));
        }

       

        fetch("http://localhost:4444/login-home", {
            method: "get",
            credentials: 'include',
            headers: {
                "Content-Type": "application/json",
            },
        })
            .then(response => response.json())
            .then(data => {
                console.log(data.message);
                setAuthorization(data.message);
            })
            .catch(error => console.error(error));
    }, [search]);

    useEffect(()=>{
        fetch("http://localhost:4444/inventory_data", {
                method: "get",
                credentials:"include",
                headers: {
                    "Content-Type": "application/json",
                },
            })
                .then(response => response.json())
                .then(data => {
                    let a=[]
                    data.data.forEach(item=>{
                        
                        if (item.quantity < 8){
                            a.push(item.name)  
                            setOpen(true)
                        }
                        
                    })
                    setLowItem(a)
                    
                })
                .catch(error => console.error(error));
    },[])

    function deleteRow(id) {
      fetch(`http://localhost:4444/deleteItem/${id}`, {
        method: "delete",
        credentials: 'include',
        headers: {
            "Content-Type": "application/json",
        },
    })
        .then(response => response.json())
        .then(data => {
            console.log(data);
        })
        .catch(error => console.error(error));
        
        window.location.reload();
      
    }


    const columns = [
      { field: 'name', headerName: 'Name', width: 250 , editable:true},
      { field: 'category', headerName: 'Category', width: 130, editable: true }, // Enable editing for category
      {
          field: 'price',
          headerName: 'Price',
          type: 'number',
          width: 90,
          default: 0,
          editable: true // Enable editing for price
      },
      {
          field: 'quantity',
          headerName: 'Quantity',
          description: 'This column has a value getter and is not sortable.',
          type: 'number',
          width: 160,
          default: 0,
          editable: true // Enable editing for quantity
      },
      {
          field: 'value',
          headerName: 'Value',
          type: 'number',
          width: 90,
          valueGetter: (value, row) => row.price * row.quantity,
      },
      {
        field: 'action',
        headerName: 'Action',
        width: 160,
        renderCell: (params) => (
            <div>
                <Link style={{height:"20px",width:"20px"}} to={`/view/${params.row._id}`}><FontAwesomeIcon style={{color:"black"}} icon={faEye} /></Link>
              <Button style={{backgroundColor:"transparent",borderColor:"transparent"}} onClick={() => deleteRow(params.row._id)}><FontAwesomeIcon style={{color:"black"}} icon={faTrash} /></Button>
            </div>
        ),
      },
  ];

  function handleEditCellChange(newData) {

    fetch("http://localhost:4444/editItem",{
      method:"post",
      headers: {
          "Content-Type": "application/json",
      },
      body:JSON.stringify(newData)
    })

    window.location.reload(); 
}


function searchData(){

    fetch(`http://localhost:4444/search/${search}`,{
        method:"get",
        headers: {
            "Content-Type": "application/json",
        },
      })
      .then(response=>response.json())
      .then(data=>setData(data.data))
      .catch(err=>console.error(err))
}


    if (!authorization) {
        return (
            <h1>Not Authorized</h1>
        )
    } else {
        return (
            <div className='home-container'>
                <Header to="user" data={location.state} />
                <div className='dashboard-container'>
                    <div className='datadiv'>
                        <h1 className='dashboard'>Dashboard</h1>  
                        <TextField type="string" label="Search" variant="outlined" sx={{marginLeft:"20%",marginRight:"20px",width:"60%"}} name='search'  required onChange={(e)=>setSearch(e.target.value)}/>
                        <DataGrid
                            className='datagrid'
                            editMode="row"
                            rows={data}
                            getRowId={(row) => row._id}
                            columns={columns}
                            processRowUpdate={(updatedRow, originalRow) =>
                              handleEditCellChange(updatedRow)
                            }
                            initialState={{
                                pagination: {
                                    paginationModel: { page: 0, pageSize: 5 },
                                },
                            }}
                            pageSizeOptions={[5, 10, 100]}
                        />
                         <Popup open={open} closeOnDocumentClick onClose={clseModel}>
                        <div className='popup'>

                                <h3>Restock</h3>

                                <h6>{lowItem} is low in stock</h6>
                                <Button onClick={clseModel}>Close</Button>

                        </div>
                    </Popup>
                    </div>
                   
                </div>
            </div>
        )
    }
}

export default Home;
