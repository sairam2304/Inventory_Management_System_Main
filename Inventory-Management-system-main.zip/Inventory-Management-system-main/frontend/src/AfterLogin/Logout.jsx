import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function Logout() {
    const navigate = useNavigate();

        fetch("http://127.0.0.1:4444/logout", {
            method: "GET",
            credentials: 'include' 
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === "success") {
                navigate("/");
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });

}

export default Logout;
