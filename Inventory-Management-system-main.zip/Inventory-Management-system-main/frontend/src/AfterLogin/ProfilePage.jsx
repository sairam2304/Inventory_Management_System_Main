import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "./ProfilePage.css"
import { useLocation } from "react-router-dom";
import Header from "../Header/header";
import validator from 'validator'
function ProfilePage() {



   


    // console.log(data);

    const navigate = useNavigate();
    const location = useLocation();
    // console.log(location.state);
    const [data,setData] = useState();
    const [profileData, setProfileData] = useState({
        username:"",
        password:"",
        fname:"",
        lname:""
    });
    const [passwordMsg, setPasswordMsg] = useState();
    const [emailMsg, setEmailMsg] = useState();

    useEffect(()=>{
        fetch("http://localhost:4444/api/portfolio",{
            method:"get",
            credentials:"include",
            headers:{
              "Content-Type": "application/json",
            }
          }
          )
          .then(response=>response.json())
          .then(data=>setProfileData(data))
          .catch(error=>console.error(error))

        //   console.log(profileData);
    },[])


    const passwordValidator = (password)=>{
        if(validator.isStrongPassword(password, { 
         minLength: 8, minLowercase: 1, 
         minUppercase: 1, minNumbers: 1, minSymbols: 1 
     })){
       return false;
     }
     else{
       setPasswordMsg("Password should be atleast 8 characters and contain atleast 1 uppercase 1 lowercase 1 number and 1 special character")
       return true;
     }
     }
     
     function checkEmail(email){
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            setEmailMsg("Invalid Email");
            return true;
        }
        return false;
      }

    function handleSubmit(){
        if(passwordValidator(profileData.password)){
            return;
        };
        if(checkEmail(profileData.username)){
            return;
        };
            
        // console.log(profileData)
        fetch("http://localhost:4444/changepassword",{
            method:"post",
            headers:{
              "Content-Type": "application/json",
            },
            body:JSON.stringify(profileData)
          }
          )
          .then(response=>response.json())
          .then(data=>{
            console.log(data)
            if(data.message){
              alert(data.message);
            }else{
              alert(data.error);
            }
          })
          .catch(error=>console.error(error))
            
      
    }

    
    return (
        <div className="home-container">
            <Header to="user" data={location.state}/>
            <div className="m-5">
                <div className="text-light mt-3">
                    <h2>User Details:</h2>
                    <div className="sub-content-txt">
                        <b>Name:</b> {profileData.fname+" "+profileData.lname} <br />
                        <b>Email:</b> {profileData.username} <br />
                    </div>
                </div>

                    <br />
                    <br />
                   
                <div className="mt-5">
                    <div className="text-light mb-3">
                        <h2>Update details:</h2>
                    </div>
                    <input
                    type="text"
                    className="fs-5 ms-0 p-2 w-25 mb-3"
                    placeholder="Enter Last Name"
                    value={profileData.fname} // Ensure this matches the property name in your state
                    onChange={(e) =>
                        setProfileData({
                            ...profileData,
                            fname: e.target.value, // Use the correct property name 'lname'
                        })
                    }
                    />
                    <br/>
                    <input
                    type="text"
                    className="fs-5 ms-0 p-2 w-25 mb-3"
                    placeholder="Enter Last Name"
                    value={profileData.lname} // Ensure this matches the property name in your state
                    onChange={(e) =>
                        setProfileData({
                            ...profileData,
                            lname: e.target.value, // Use the correct property name 'lname'
                        })
                    }
                    />

                    <br />
                    <input
                        type="text"
                        className="fs-5 ms-0 p-1 w-25 mb-3"
                        placeholder="Enter EMAIL"
                        value={profileData.username}
                        readOnly
                        
                    />
                    <br />
                    <span style={{color:"red"}}>{emailMsg}</span>
                    <br />
                    <input
                        type="password"
                        className="fs-5 ms-0 p-1 w-25 mb-3"
                        placeholder="Enter New Password"
                        onChange={(e) =>
                            setProfileData({
                                ...profileData,
                                password: e.target.value,
                            })  
                        }
                    /><br/>
                     <span style={{color:"red"}}>{passwordMsg}</span>
                    <br />
                    <Button className="btn-primary fs-5" onClick={handleSubmit}> 
                        Update
                    </Button>
                </div>
            </div>
        </div>
    );
}

export default ProfilePage;