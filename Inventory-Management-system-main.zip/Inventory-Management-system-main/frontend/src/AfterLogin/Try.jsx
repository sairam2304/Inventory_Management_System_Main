import React, { useState } from 'react';
import "../"

const ImageUploadComponent = () => {
  const [image, setImage] = useState(null);

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onloadend = () => {
      // Store the uploaded image in state
      setImage(reader.result);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleUpload = () => {
    if (image) {
      const formData = new FormData();
      formData.append('image', image);

      // Send the image data to the backend server
      fetch('http://localhost:5000/upload', {
        method: 'POST',
        body: formData,
      })
        .then((response) => response.text())
        .then((result) => {
          console.log(result);
          // Do something with the result if needed
        })
        .catch((error) => {
          console.error('Error:', error);
        });
    } else {
      console.log('No image to upload');
    }
  };

  
  return (
    <div>
      <input type="file" accept="image/*" onChange={handleImageUpload} />
      {image && <img src={image} alt="Uploaded" style={{ maxWidth: '100px', maxHeight: '100px' }} />}
      <button onClick={handleUpload}>Upload</button>
    </div>
  );
};

export default ImageUploadComponent;
