import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Header from "../Header/header";
import './ViewItem.css'; // Import your CSS file for styling

function ViewItem() {
    const { id } = useParams();
    const [data, setData] = useState({});

    useEffect(() => {
        fetch(`http://localhost:4444/item/${id}`, {
            method: "get",
            credentials: "include",
            headers: {
                "Content-Type": "application/json",
            },
        })
            .then(response => response.json())
            .then(data => {
                setData(data.data);
            })
            .catch(error => console.error(error));
    }, [id]); // Include id in the dependency array to re-fetch data when id changes

    return (
        <div >
            <Header to="user"/>
            <div className="item-details view-item-container">
            <h1 className="item-name">{data.name}</h1>
                <img className="item-image" src={data.url} alt={data.name} />
                <div className="item-description">
                    <h2>Description</h2>
                    <p>{data.description}</p>
                </div>
                <div className="item-info">
                    <div className="item-price">
                        <h2>Price:</h2>
                        <p>${data.price}</p>
                    </div>
                    <div className="item-quantity">
                        <h2>Quantity:</h2>
                        <p>{data.quantity}</p>
                    </div>
                    </div>
            </div>
        </div>
    );
}

export default ViewItem;
