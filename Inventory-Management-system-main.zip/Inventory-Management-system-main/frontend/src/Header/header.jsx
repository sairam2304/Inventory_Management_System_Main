import React from 'react'
import { Navbar,Nav,Container,Button } from 'react-bootstrap'
import { Link, NavLink } from 'react-router-dom'
import Login from "../Login/Login"

function user(data){
    return (
        <Navbar bg="dark">
        <Container>
            
                <Link className='badge badge-primary me-2' to="/home" state={data} style={{fontSize:"15px"}}>IMS</Link>
                {/* 🏂👻💀🧟 */}
            
            <Navbar.Toggle aria-controls="navbarScroll" />
            <Navbar.Collapse id="navbarScroll">
                    <Nav
                        className="me-auto my-2 my-lg-0"
                        style={{maxHeight: '100px'}}
                        navbarScroll
                    >
                         
                </Nav>
                <Link className='badge badge-primary me-2' to="/profile" state={data} style={{fontSize:"15px"}}>Profile</Link>
                <Link className='badge badge-primary me-2' to="/create" style={{fontSize:"15px"}}>New Entry</Link>
                <Link className='badge badge-primary me-2' to="/analysis" style={{fontSize:"15px"}}>Analysis</Link>
                <Link className='badge badge-primary me-2' to="/logout" style={{fontSize:"15px"}}>Log Out</Link>
                

            </Navbar.Collapse>
        </Container>
    </Navbar>
    )
}

function before(){

  return (
    <Navbar bg="dark">
        <Container>
            <Navbar.Brand href='/' style={{color: "white"}}>
                IMS
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="navbarScroll" />
            <Navbar.Collapse id="navbarScroll">
                    <Nav
                        className="me-auto my-2 my-lg-0"
                        style={{maxHeight: '100px'}}
                        navbarScroll
                    >
                         
                </Nav>
                <Link className='badge badge-primary me-2' to="/login" style={{fontSize:"15px"}}>Login</Link>
                <Link className='badge badge-primary me-2' to="/register" style={{fontSize:"15px"}}>Register</Link>
                <Link className='badge badge-primary me-2' to="/contactus" style={{fontSize:"15px"}}>Contact Us</Link>
                

            </Navbar.Collapse>
        </Container>
    </Navbar>
    
  )

}
function whichNav(navto,data=null) {
    if (navto === "before") {
        return before();
    } else if (navto === "user") {
        return user(data);
    }
    // else if(navto === "dashboard"){
    //   return dashboard();
    // }
}

function Header(props) {


    return (
        
            
            whichNav(props.to,props.data)
    );



}

export default Header