import React from 'react'
import "./Login.css"
import { Button } from 'react-bootstrap'
import Header from '../Header/header'
import { useState } from 'react'
import { TextField } from '@mui/material'
import { Link, useNavigate } from 'react-router-dom'


function Login() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setErrors] = useState({});

  const navigate = useNavigate();

  function checkEmail(email){
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return true;
    }
    return false;
  }


  function signIn() {


    if(checkEmail(email) || password.length === ""){
      setErrors({
        email: checkEmail(email),
        password: password.length === 0
    });
    return;
    }

    const updatedData = {
      username:email,
      password:password,
    }
    
    fetch("http://localhost:4444/login",{
      method:"post",
      credentials:'include',
      headers:{
        "Content-Type": "application/json",
      },
      body:JSON.stringify(updatedData)
    }
    )
    .then(response=>response.json())
    .then(data=>{
      if(data.message === "Login successful"){
        navigate("/home", {state:data.user})
      }else{
        alert(data.message);
      }
    })
    .catch(error=>console.error(error))
  }

  return (
    <div style={{minHeight: '100vh'}} className='home-container'>
      <Header to="before"/>
    <div className='signin-container '>
        <div className='signin-box'>
        <h2>Sign In</h2>
            <div className='mb-3'>
            <TextField type="string" label="email" variant="outlined" sx={{margin:"2% auto",width:"80%"}} error={error.email} required onChange={(e)=>setEmail(e.target.value)}/><br/>
            <TextField type="password" label="password" variant="outlined" sx={{margin:"2% auto",width:"80%"}} error={error.password} required onChange={(e)=>setPassword(e.target.value)}/><br/>
            </div>
        <Button onClick={()=>signIn()} className='mt-3'>Signin</Button>
        <p><br/>Don't have an account?</p>
        <Link to="/register" className='btn btn-primary'>Register</Link>

    </div>
    </div>
    </div>
    
  )
}

export default Login