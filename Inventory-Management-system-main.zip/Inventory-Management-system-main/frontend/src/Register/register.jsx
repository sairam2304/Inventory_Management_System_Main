import React from 'react'
import "./Login.css"
import { Button } from 'react-bootstrap'
import Header from '../Header/header'
import { useState } from 'react'
import { TextField } from '@mui/material'
import { Link } from 'react-router-dom'
import validator from 'validator'
import Select from 'react-select'
import "./Register.css"

function Register() {
  
  const [data, setData] = useState({
    fname:"",
    lname:"",
    email:"",
    password:"",
    password2:"",
    company:"",
  });
  const [passwordMsg, setPasswordMsg] = useState("");

  const [error, setErrors] = useState({});

  
  const categories = [
    { value: 'Walmart', label: 'Walmart' },
    { value: 'Nykaa', label: 'Nykaa' },
    { value: 'Myntra', label: 'Myntra' }
    
  ]

  function checkEmail(email){
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
        return true;
    }
    return false;
  }
  
  const passwordValidator = (password)=>{
     if(validator.isStrongPassword(password, { 
      minLength: 8, minLowercase: 1, 
      minUppercase: 1, minNumbers: 1, minSymbols: 1 
  })){
    return false;
  }
  else{
    setPasswordMsg("Password should be atleast 8 characters and contain atleast 1 uppercase 1 lowercase 1 number and 1 special character")
    return true;
  }
  }


  function signIn() {


    if(checkEmail(data.email)|| passwordValidator(data.password) ||data.fname.length === 0||data.lname.length === 0||data.password!==data.password2){
      setErrors({
        email: checkEmail(data.email),
        password: passwordValidator(data.password),
        fname:data.fname.length === 0,
        lname:data.lname.length === 0,
        password2:data.password!==data.password2
    });
    return; 
    }

    const updatedData = {
      fname:data.fname,
      lname: data.lname,
      username:data.email,
      password:data.password,
      company:data.company,
    }
    // console.log(updatedData);
    fetch("http://localhost:4444/register",{
      method:"post",
      headers:{
        "Content-Type": "application/json",
      },
      body:JSON.stringify(updatedData)
    }
    )
    .then(response=>response.json())
    .then(data=>{
      if(data.message){
        alert(data.message);
      }else{
        alert(data.error);
      }
    })
    .catch(error=>console.error(error))

  }

  

  return (
    <div style={{minHeight: '100vh'}} className='home-container'>
      <Header to="before"/>
    <div className='signin-container'>
        <div className='signin-box'>
        <h2>Register</h2>
            <div className='mb-3'>
            
            <TextField type="string" label="First Name" variant="outlined" sx={{margin:"2% auto",width:"100%"}} name='fname' error={error.fname} required onChange={(e)=>setData({...data, fname:e.target.value})}/><br/>
            <TextField type="string" label="Last Name" variant="outlined" sx={{margin:"2% auto",width:"100%"}} name='lname' error={error.lname} required onChange={(e)=>setData({...data, lname:e.target.value})}/><br/>
            <TextField type="string" label="Email" variant="outlined" sx={{margin:"2% auto",width:"100%"}} name='email' error={error.email} required onChange={(e)=>setData({...data, email:e.target.value})}/><br/>
            <Select className='select' options={categories} required  onChange={(e)=>setData({...data, company:e.value})}/>
            <TextField type="password" label="Password" variant="outlined" sx={{margin:"2% auto",width:"100%"}} name='password' error={error.password} required onChange={(e)=>setData({...data, password:e.target.value})}/><br/>
            <span style={{color:"red"}}>{passwordMsg}</span>
            <TextField type="password" label="Confirm Password" variant="outlined" sx={{margin:"2% auto",width:"100%"}} name='password' error={error.password2} required onChange={(e)=>setData({...data, password2:e.target.value})}/><br/>
            </div>
            
        
        <Button onClick={()=>signIn()} className='mt-3'>Register</Button>

    </div>
    </div>
    </div>
    
  )
}

export default Register;