import { Routes,Route, BrowserRouter } from 'react-router-dom';

import React from 'react'
import App from './App';
import Login from './Login/Login';
import HomePage from './homepage/HomePage';
import Register from './Register/register';
import Home from './AfterLogin/HomePage';
import ProfilePage from './AfterLogin/ProfilePage';
import EditInv from './AfterLogin/EditInv';
import Logout from './AfterLogin/Logout';
import TRY from './AfterLogin/Try'
import ViewItem from './AfterLogin/ViewItem';
import Analysis from './AfterLogin/Analysis';
import Contactus from './contact_us/Contactus';

function Paths() {
    return (
        <BrowserRouter>
        <Routes>
          <Route path='/' element={<HomePage />} />
          <Route path='/login' element={<Login />} />
          <Route path='/register' element={<Register />} />
          <Route path='/home' element={<Home />} />
          <Route path='/profile' element={<ProfilePage />} />
          <Route path='/create' element={<EditInv />} />
          <Route path='/logout' element={<Logout />} />
          <Route path='/analysis' element={<Analysis />} />
          <Route path='/view/:id' element={<ViewItem />} />
          <Route path='/contactus' element={<Contactus />} />

          <Route path='/try' element={<TRY />} />
        </Routes>
        </BrowserRouter>
    
        
      );
}

export default Paths;