import React from 'react';

function BoxDetails(props) {
  return (
    <div style={{ backgroundColor: "white", height: "200px", width: "200px", display: "flex", justifyContent: "center", alignItems: "center", marginBottom:"50px"}}>
      <div>
        <div>{props.logo}</div>
        <div>{props.text}</div>
      </div>
    </div>
  );
}

export default BoxDetails;
