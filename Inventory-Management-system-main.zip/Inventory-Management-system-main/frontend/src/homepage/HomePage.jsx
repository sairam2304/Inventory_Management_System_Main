import React from 'react';
import Header from '../Header/header';

import "./HomePage.css";

function HomePage() {
  return (
    <div>
      <Header to="before" />
      <div className='home-container'>
      </div>
    </div>
  );
}

export default HomePage;